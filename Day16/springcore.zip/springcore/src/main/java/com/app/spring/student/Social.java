package com.app.spring.student;

public class Social implements Teacher {

	public void name() {
		System.out.println("Teacher is Priya");
		
	}

	public void teach() {
		System.out.println(" Priya teaches Social");
		
	}

}

