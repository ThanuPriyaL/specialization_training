package com.demo.cars;

import org.springframework.stereotype.Component;

@Component
public class Cars {
	public void demo() {
		
	}
	public void getfeat() {
		System.out.println("Has Great Features ");
	}
}
	

