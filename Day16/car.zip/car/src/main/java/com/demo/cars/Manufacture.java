package com.demo.cars;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Manufacture {
	
	@Autowired
	Cars cars;
	
	public void buildcar() {
		cars.demo();
	}
	
}
