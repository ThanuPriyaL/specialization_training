package com.demo.models;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.cars.Bmw;
import com.demo.cars.Manufacture;
import com.demo.cars.Swift;

public class App
{
public static void main( String[] args )
{

	
ApplicationContext context = new AnnotationConfigApplicationContext(CarConfig.class);
Manufacture man = context.getBean("manufacture",Manufacture.class);
man.buildcar();
}
}
