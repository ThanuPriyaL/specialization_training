package com.example.restapi.service;

import com.example.restapi.model.Student;
import com.example.restapi.repo.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    @Autowired
    StudentRepo repo;
    public void store(Student std) {
        repo.save(std);
    }

    public List<Student> getStudents() {

        List<Student> list=repo.findAll();

        return list;
    }

    public Student getStudent(int id) {

        Student stu=repo.findById(id).orElse(new Student());

        return stu;
    }

    public void deleteStd(int id) {
        repo.deleteById(id);
    }
}
