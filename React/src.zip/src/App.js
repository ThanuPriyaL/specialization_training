
import './App.css';
import Home from './components/home';
import  Info from './components/info'
// /import Home from './components/home'
import About from './components/about';

import { Component } from 'react';

function App() {
  return (
    <div className="App">
      <div>
        <Info></Info>
      {/* <Info name="mahesh" /> */}
        {/* <Home></Home> */}
        
         {/* <About name="mahesh" age="22"><h2>this is child property from parent</h2></About>
         <About name="mahi" age="20"/> */}
        
      
      </div>
    </div>
  );
}

// class App extends Component
// {
//   constructor()
//   {
//     super();
//   }
//   render()
//   {
//     return (
      
//       <div>
//           <h1>React Js</h1>
//       </div>
      
//     );
//   }
// }
export default App;

