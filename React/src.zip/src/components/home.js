import  React from 'react';

// function Home() {
//     return (
//       <div className="App">
//         <div>
//           <h1>This is Home component</h1>
//         </div>
//       </div>
//     );
//   }

  const Home= ()=>{
    return (
      
        <div>
          <h1>This is functional component</h1>
        </div>
      
    );
  }

  //named component

  // export const Home=()=>{
  //   return (
  //     <div className="App">
  //       <div>
  //         <h1>This is Home component</h1>
  //       </div>
  //     </div>
  //   );
  // }
  export default Home;