import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  emp:Employee = new Employee();

  constructor( private employee:EmployeeService) { }

  ngOnInit(): void {
  }
  
  save(obj:any){
   this.emp.id=obj.id;
   this.emp.name=obj.name;
   this.emp.city=obj.city;
   this.employee.saveEmp(this.emp);
  }
}
